<?php
App::uses('AppController', 'Controller');

class MailchimpAppController extends AppController {
}
